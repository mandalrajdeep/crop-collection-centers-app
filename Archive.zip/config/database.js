module.exports = {

    'url' : 'mongodb://efasal:pastor%40321@cluster0-shard-00-00-84sxp.mongodb.net:27017,cluster0-shard-00-01-84sxp.mongodb.net:27017,cluster0-shard-00-02-84sxp.mongodb.net:27017/eFasal?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};
