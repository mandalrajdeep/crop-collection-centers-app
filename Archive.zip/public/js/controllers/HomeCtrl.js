app.controller('HomeCtrl', function($scope) {
    $scope.driverlist = [
    {
        points: 123,
        country: 'IN'
    },
    {
        points: 456,
        country: 'IN'
    },
    {
        points: 789,
        country: 'IN'
    }
    ];
 
});